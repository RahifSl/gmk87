# Industrial Hardware Cockpit Visual Overhaul for GMK87 Master Control Center

A comprehensive design overhaul transforming the GMK87 Master Control Center into an **Industrial Hardware Cockpit** inspired by **Wootility v5** and **Teenage Engineering**, pairing a left vertical icon-and-label studio sidebar with a 3D sculpted mechanical keyboard deck, machined aluminum chassis with gasket mounting accents, tactile hardware controls, and precision micro-typography.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following visual direction and architectural choices were confirmed via the user interview:
> - **Visual Aesthetic**: Industrial Hardware Cockpit (Wootility / Teenage Engineering / Braun / Dieter Rams functional precision).
> - **Shell & Navigation Layout**: Fixed left vertical studio navigation sidebar (icon + label + badge) with full-height fluid canvas workspace.
> - **Keyboard Deck Upgrades**: 3D sculpted keycap profiles with authentic spherical/cylindrical dish shadows, laser legends, switch stem depth, per-key RGB backlight underglow, machined aluminum/polycarbonate gasket chassis with hex socket bolts, knurled CNC rotary encoder knob with brushed metallic graduation lines.
> - **UI Controls**: Tactile stepped hardware sliders with tick marks, mechanical toggle switches, recessed port bays, technical coordinate/grid backgrounds, and crisp monospace telemetry.

---

## 1. Overview & Core Concept

- **What It Does**: Overhauls the visual appearance and layout architecture of the entire GMK87 Master Control Center. Replaces standard flat cards and horizontal tab strips with an authoritative, precision-engineered hardware cockpit.
- **Target Audience**: Mechanical keyboard enthusiasts, competitive gamers, firmware tinkerers, and custom hardware creators using the Zuoya GMK87.
- **Key Value**: Delivers the tactile feel and visual authenticity of professional instrument software (Wooting, Teenage Engineering, Elektron, SignalRGB) while keeping all WebHID USB streaming, 240×135 TFT LCD flashing, and VIA key remapping fully functional.

---

## 2. User Experience & Visual Design

### A. Layout Architecture: Left Vertical Studio Sidebar & Full-Height Canvas

```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ GMK87 COCKPIT TOP INSTRUMENT RIBBON (40px)                                                             │
│ [Zuoya GMK87] [VID:0x320F PID:0x5055]   [USB 1000Hz ⚡]   [240×135 TFT Mini HUD]   [Connect / Sync]    │
├───────────────┬────────────────────────────────────────────────────────────────────────────────────────┤
│ LEFT VERTICAL │ MAIN HARDWARE WORKSPACE (Fluid Canvas)                                                 │
│ STUDIO RAIL   │                                                                                        │
│ (240px wide)  │ ┌────────────────────────────────────────────────────────────────────────────────────┐ │
│               │ │ 3D GASKET-MOUNTED CHASSIS & KEYCAP DECK (Hex Bolts, Metallic Knob, South Glow)     │ │
│ [⌨ Keymap]    │ │ ┌───┐ ┌───┐ ┌───┐ ... ┌───────────────┐ ┌──────┐ [Knurled CNC Dial]               │ │
│ [🎛 Knob]      │ │ └───┘ └───┘ └───┘     │  240×135 TFT  │ │ 87-K │ [CCW: VOL- | CW: VOL+ | Push]    │ │
│ [🎁 Screen]    │ │                       └───────────────┘ └──────┘                             │ │
│ [💡 RGB Halo] │ └────────────────────────────────────────────────────────────────────────────────────┘ │
│ [📊 Live HUD] │                                                                                        │
│ [⏱ RTC Clock] │ ┌────────────────────────────────────────────────────────────────────────────────────┐ │
│ [🔬 Lab OSD]  │ │ RECESSED DOCK / SUB-ENGINE PANELS                                                  │ │
│ [📖 Shortcuts]│ │ (Stepped Hardware Sliders, 16-Bit Hex Inspector, Rotary Mode Drawer, Colorways)   │ │
│               │ └────────────────────────────────────────────────────────────────────────────────────┘ │
│ ───────────── │                                                                                        │
│ [USB Bridge]  │                                                                                        │
│ [Flash Queue] │                                                                                        │
└───────────────┴────────────────────────────────────────────────────────────────────────────────────────┘
```

### B. Visual Identity & Color Palette (Industrial Hardware Cockpit)

- **60% Dominant Neutral Canvas**: Deep Obsidian Matte (`#080b11`) with subtle precision grid backdrop lines (`#111827` at 24px intervals) and hairline panel dividers (`#1a2333`).
- **30% Structural Surfaces**:
  - Machined aluminum chassis plate: Textured dark anodized graphite (`#0d131f` to `#141d2e`).
  - Gasket mount perimeter: Chamfered bezel with micro hex bolt insets (`#2a364f`).
  - 3D Sculpted Keycaps: Multi-layer CSS shadow and gradient construction (`box-shadow: 0 4px 0 #05080f, 0 6px 12px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.12)`).
- **10% Calibrated Telemetry Accents**:
  - Instrument Laser Cyan (`#06b6d4` / `#22d3ee`) for active states and LCD telemetry.
  - Engineering Amber (`#f59e0b` / `#fbbf24`) for warnings and clock offsets.
  - Signal Emerald (`#10b981` / `#34d399`) for successful hardware commits and USB link status.
  - Tactical Mecha Orange/Red (`#f43f5e`) for destructive/reset operations.

### C. Typography & Precision Micro-Notation

- **Interface Labels & Section Titles**: `JetBrains Mono` and `Plus Jakarta Sans` with uppercase micro-tracking (`tracking-wider`, `text-[10px] font-mono font-bold text-slate-400`).
- **Data & Telemetry Values**: `font-mono tabular-nums` for all packet offsets, frame counts, byte streams, and clock registers.
- **Zero-Pill Restraint**: Metadata presented as unboxed technical lines (`USB-C · REPORT 0x04 · CHUNK 56B`) without rounded jelly pill capsules.

---

## 3. Key Product & Component Upgrades

### A. 3D Sculpted Keycaps & Machined Chassis Overhaul
- **Realistic Dish Depressions & Stepped Keycap Heights**: Each keycap styled with convex top surfaces, side bevels, and crisp font legends mimicking authentic double-shot PBT keycaps.
- **Authentic South-Facing LED Underglow**: Real-time ray-cast diffused glow underneath keycaps reflecting the active hardware lighting mode (`cfg[1]`) or custom colorway.
- **Knurled Aluminum Rotary Encoder**: Stylized CNC metal dial with radial tick notches, smooth rotation animation, and indicator needle.
- **Recessed TFT Screen Bezel**: Screen enclosure styled like an authentic instrument panel with glass glare reflection and micro bezel screws.

### B. Left Vertical Studio Sidebar
- Pinned left sidebar housing the 8 specialized studios with status pips, active transport indicator, quick Slot 0/1 toggle, and immediate access to hardware reset.
- Mobile/narrow-screen collapsible drawer mode with full touch support.

### C. Tactile Hardware UI Controls
- **Industrial Stepped Sliders**: Custom range slider rails with engraved tick marks (1 to 5 for Speed, 0 to 9 for Brightness) and tactile knurled thumb sliders.
- **Machined Toggle Switches**: Realistic rocker/toggle switches for Dithering, Auto-Sync, and South-Facing Glow instead of flat mobile pill toggles.
- **Recessed Terminal Bays**: EEPROM buffer and HID packet inspector styled as an oscillographic hardware telemetry drawer.

---

## 4. Technical Architecture & Component Mapping

```
App.tsx (Root Layout)
├── TopInstrumentBar (Hardware VID/PID status, active device, tray control, quick clock)
├── LeftStudioSidebar (8 Studio Tabs + USB Bridge Monitor + Flash Buffer Queue)
└── WorkspaceContainer (Full-Height Fluid Grid)
    ├── Studio 1: Keymap & Rotary Studio (3D Gasket Chassis + Drag/Drop + Keycap Themes)
    ├── Studio 2: 240×135 Screen Studio (Web GIFs + Sprites + Procedural + Pixel Painter)
    ├── Studio 3: RGB & Underglow Studio (19 Modes + 360° Halo + HSV Spectrum Pickers)
    ├── Studio 4: Live Telemetry & HUD (Windows CPU/RAM + 24-Band Spectrum + RTC Sync)
    ├── Studio 5: Beyond-Zuoya OSD Lab (WPM Tachometer + Pomodoro Focus Engine)
    ├── Studio 6: Hardware Shortcuts & HID Diagnostics (Interactive 87-Key Trainer + Packets)
    └── PersistentMiniMonitorHUD (Inline Dock + Floating PiP Screen)
```

---

## 5. Verification Plan

- Run `compile_applet` and `lint_applet` to ensure zero TypeScript errors.
- Verify left sidebar navigation and layout across 1440px desktop, laptop, and responsive tablet widths.
- Ensure all WebHID, Node-HID Bridge, 240×135 TFT screen flashing, and VIA keycode drag-and-drop operations remain 100% operational.
