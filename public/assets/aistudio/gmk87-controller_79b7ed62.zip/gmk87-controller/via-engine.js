const HID = require('node-hid');

const VENDOR_ID = 0x320f;
const PRODUCT_ID = 0x5055;
const ROWS = 8;
const COLS = 15;
const LAYERS = 4;

function getViaDevice() {
  const d = HID.devices().find(
    (x) => x.vendorId === VENDOR_ID && x.productId === PRODUCT_ID && x.interface === 1
  );
  if (!d) throw new Error('GMK87 VIA interface not found');
  return new HID.HID(d.path);
}

// QMK Keycodes Dictionary for GMK87 (VIA Protocol 9)
const KEYCODES = {
  // Basic & Alphanumeric
  0x0000: { label: 'NO', name: 'None / Disabled', cat: 'Special' },
  0x0001: { label: 'TRNS', name: 'Transparent (Pass through)', cat: 'Special' },
  0x0029: { label: 'ESC', name: 'Escape', cat: 'Basic' },
  0x0004: { label: 'A', name: 'Key A', cat: 'Alpha' },
  0x0005: { label: 'B', name: 'Key B', cat: 'Alpha' },
  0x0006: { label: 'C', name: 'Key C', cat: 'Alpha' },
  0x0007: { label: 'D', name: 'Key D', cat: 'Alpha' },
  0x0008: { label: 'E', name: 'Key E', cat: 'Alpha' },
  0x0009: { label: 'F', name: 'Key F', cat: 'Alpha' },
  0x000A: { label: 'G', name: 'Key G', cat: 'Alpha' },
  0x000B: { label: 'H', name: 'Key H', cat: 'Alpha' },
  0x000C: { label: 'I', name: 'Key I', cat: 'Alpha' },
  0x000D: { label: 'J', name: 'Key J', cat: 'Alpha' },
  0x000E: { label: 'K', name: 'Key K', cat: 'Alpha' },
  0x000F: { label: 'L', name: 'Key L', cat: 'Alpha' },
  0x0010: { label: 'M', name: 'Key M', cat: 'Alpha' },
  0x0011: { label: 'N', name: 'Key N', cat: 'Alpha' },
  0x0012: { label: 'O', name: 'Key O', cat: 'Alpha' },
  0x0013: { label: 'P', name: 'Key P', cat: 'Alpha' },
  0x0014: { label: 'Q', name: 'Key Q', cat: 'Alpha' },
  0x0015: { label: 'R', name: 'Key R', cat: 'Alpha' },
  0x0016: { label: 'S', name: 'Key S', cat: 'Alpha' },
  0x0017: { label: 'T', name: 'Key T', cat: 'Alpha' },
  0x0018: { label: 'U', name: 'Key U', cat: 'Alpha' },
  0x0019: { label: 'V', name: 'Key V', cat: 'Alpha' },
  0x001A: { label: 'W', name: 'Key W', cat: 'Alpha' },
  0x001B: { label: 'X', name: 'Key X', cat: 'Alpha' },
  0x001C: { label: 'Y', name: 'Key Y', cat: 'Alpha' },
  0x001D: { label: 'Z', name: 'Key Z', cat: 'Alpha' },
  0x001E: { label: '1 !', name: '1 / Exclamation', cat: 'Number' },
  0x001F: { label: '2 @', name: '2 / At', cat: 'Number' },
  0x0020: { label: '3 #', name: '3 / Hash', cat: 'Number' },
  0x0021: { label: '4 $', name: '4 / Dollar', cat: 'Number' },
  0x0022: { label: '5 %', name: '5 / Percent', cat: 'Number' },
  0x0023: { label: '6 ^', name: '6 / Caret', cat: 'Number' },
  0x0024: { label: '7 &', name: '7 / Ampersand', cat: 'Number' },
  0x0025: { label: '8 *', name: '8 / Asterisk', cat: 'Number' },
  0x0026: { label: '9 (', name: '9 / Left Paren', cat: 'Number' },
  0x0027: { label: '0 )', name: '0 / Right Paren', cat: 'Number' },
  0x0028: { label: 'ENTER', name: 'Return / Enter', cat: 'Basic' },
  0x002A: { label: 'BKSP', name: 'Backspace', cat: 'Basic' },
  0x002B: { label: 'TAB', name: 'Tab', cat: 'Basic' },
  0x002C: { label: 'SPACE', name: 'Spacebar', cat: 'Basic' },
  0x002D: { label: '- _', name: 'Minus / Underscore', cat: 'Basic' },
  0x002E: { label: '= +', name: 'Equal / Plus', cat: 'Basic' },
  0x002F: { label: '[ {', name: 'Left Bracket', cat: 'Basic' },
  0x0030: { label: '] }', name: 'Right Bracket', cat: 'Basic' },
  0x0031: { label: '\\ |', name: 'Backslash / Pipe', cat: 'Basic' },
  0x0033: { label: '; :', name: 'Semicolon / Colon', cat: 'Basic' },
  0x0034: { label: '\' "', name: 'Single / Double Quote', cat: 'Basic' },
  0x0035: { label: '` ~', name: 'Grave / Tilde', cat: 'Basic' },
  0x0036: { label: ', <', name: 'Comma / Less Than', cat: 'Basic' },
  0x0037: { label: '. >', name: 'Period / Greater Than', cat: 'Basic' },
  0x0038: { label: '/ ?', name: 'Slash / Question Mark', cat: 'Basic' },
  0x0039: { label: 'CAPS', name: 'Caps Lock', cat: 'Basic' },

  // Function Keys
  0x003A: { label: 'F1', name: 'F1', cat: 'Function' },
  0x003B: { label: 'F2', name: 'F2', cat: 'Function' },
  0x003C: { label: 'F3', name: 'F3', cat: 'Function' },
  0x003D: { label: 'F4', name: 'F4', cat: 'Function' },
  0x003E: { label: 'F5', name: 'F5', cat: 'Function' },
  0x003F: { label: 'F6', name: 'F6', cat: 'Function' },
  0x0040: { label: 'F7', name: 'F7', cat: 'Function' },
  0x0041: { label: 'F8', name: 'F8', cat: 'Function' },
  0x0042: { label: 'F9', name: 'F9', cat: 'Function' },
  0x0043: { label: 'F10', name: 'F10', cat: 'Function' },
  0x0044: { label: 'F11', name: 'F11', cat: 'Function' },
  0x0045: { label: 'F12', name: 'F12', cat: 'Function' },
  0x0046: { label: 'PSCR', name: 'Print Screen', cat: 'Nav' },
  0x0047: { label: 'SLCK', name: 'Scroll Lock', cat: 'Nav' },
  0x0048: { label: 'PAUS', name: 'Pause / Break', cat: 'Nav' },
  0x0049: { label: 'INS', name: 'Insert', cat: 'Nav' },
  0x004A: { label: 'HOME', name: 'Home', cat: 'Nav' },
  0x004B: { label: 'PGUP', name: 'Page Up', cat: 'Nav' },
  0x004C: { label: 'DEL', name: 'Delete', cat: 'Nav' },
  0x004D: { label: 'END', name: 'End', cat: 'Nav' },
  0x004E: { label: 'PGDN', name: 'Page Down', cat: 'Nav' },
  0x004F: { label: 'RIGHT', name: 'Right Arrow', cat: 'Nav' },
  0x0050: { label: 'LEFT', name: 'Left Arrow', cat: 'Nav' },
  0x0051: { label: 'DOWN', name: 'Down Arrow', cat: 'Nav' },
  0x0052: { label: 'UP', name: 'Up Arrow', cat: 'Nav' },

  // Modifiers
  0x00E0: { label: 'LCTRL', name: 'Left Control', cat: 'Modifier' },
  0x00E1: { label: 'LSHIFT', name: 'Left Shift', cat: 'Modifier' },
  0x00E2: { label: 'LALT', name: 'Left Alt / Option', cat: 'Modifier' },
  0x00E3: { label: 'LGUI', name: 'Left Win / Command', cat: 'Modifier' },
  0x00E4: { label: 'RCTRL', name: 'Right Control', cat: 'Modifier' },
  0x00E5: { label: 'RSHIFT', name: 'Right Shift', cat: 'Modifier' },
  0x00E6: { label: 'RALT', name: 'Right Alt / Option', cat: 'Modifier' },
  0x00E7: { label: 'RGUI', name: 'Right Win / Command', cat: 'Modifier' },

  // Media & Knob Controls
  0x00A8: { label: 'MUTE', name: 'Mute Audio', cat: 'Media' },
  0x00A9: { label: 'VOL+', name: 'Volume Increment', cat: 'Media' },
  0x00AA: { label: 'VOL-', name: 'Volume Decrement', cat: 'Media' },
  0x00AB: { label: 'MNXT', name: 'Next Media Track', cat: 'Media' },
  0x00AC: { label: 'MPRV', name: 'Previous Media Track', cat: 'Media' },
  0x00AD: { label: 'MSTP', name: 'Media Stop', cat: 'Media' },
  0x00CD: { label: 'MPLY', name: 'Play / Pause', cat: 'Media' },
  0x00B0: { label: 'CALC', name: 'Calculator', cat: 'Media' },
  0x00B1: { label: 'MAIL', name: 'Default Mail', cat: 'Media' },
  0x00B2: { label: 'MSEL', name: 'Media Player', cat: 'Media' },
  0x00B3: { label: 'MYCM', name: 'My Computer', cat: 'Media' },
  0x00B4: { label: 'WSCH', name: 'Web Search', cat: 'Media' },
  0x00B5: { label: 'WHOM', name: 'Web Browser Home', cat: 'Media' },

  // Layer Switching (GMK87 Legacy Protocol 9)
  0x5101: { label: 'MO(1)', name: 'Momentary Layer 1 (Fn)', cat: 'Layers' },
  0x5102: { label: 'MO(2)', name: 'Momentary Layer 2', cat: 'Layers' },
  0x5103: { label: 'MO(3)', name: 'Momentary Layer 3', cat: 'Layers' },
  0x5010: { label: 'TO(0)', name: 'Switch to Layer 0', cat: 'Layers' },
  0x5011: { label: 'TO(1)', name: 'Switch to Layer 1', cat: 'Layers' },
  0x5012: { label: 'TO(2)', name: 'Switch to Layer 2', cat: 'Layers' },
  0x5013: { label: 'TO(3)', name: 'Switch to Layer 3', cat: 'Layers' },

  // Special GMK87 Vendor / Lighting Keycodes
  0x5F10: { label: 'FN', name: 'Fn Key (Hardware)', cat: 'Special' },
  0x5F80: { label: '2.4G', name: 'Switch to 2.4G Wireless', cat: 'Hardware' },
  0x5F81: { label: 'BT1', name: 'Connect Bluetooth 1', cat: 'Hardware' },
  0x5F82: { label: 'BT2', name: 'Connect Bluetooth 2', cat: 'Hardware' },
  0x5F83: { label: 'BT3', name: 'Connect Bluetooth 3', cat: 'Hardware' },
  0x5F84: { label: 'LOCK WIN', name: 'Lock Windows Key', cat: 'Hardware' },
  0x5F87: { label: 'LOGO MODE', name: 'Logo LED Mode', cat: 'Lighting' },
  0x5F88: { label: 'LOGO COLOR', name: 'Logo LED Color', cat: 'Lighting' },
  0x5F89: { label: 'SCREEN PAGE', name: 'Switch Screen Page', cat: 'Hardware' },
  0x5F8B: { label: 'SCREEN PWR', name: 'Screen Power Toggle', cat: 'Hardware' },
  0x5CC2: { label: 'RGB TOG', name: 'RGB Toggle On/Off', cat: 'Lighting' },
  0x5CC3: { label: 'RGB MOD+', name: 'RGB Mode Next', cat: 'Lighting' },
  0x5CC4: { label: 'RGB MOD-', name: 'RGB Mode Prev', cat: 'Lighting' },
  0x5CC5: { label: 'RGB HUE+', name: 'RGB Hue Increase', cat: 'Lighting' },
  0x5CC6: { label: 'RGB HUE-', name: 'RGB Hue Decrease', cat: 'Lighting' },
  0x5CC7: { label: 'RGB SAT+', name: 'RGB Saturation Increase', cat: 'Lighting' },
  0x5CC8: { label: 'RGB SAT-', name: 'RGB Saturation Decrease', cat: 'Lighting' },
  0x5CC9: { label: 'RGB BRI+', name: 'RGB Brightness Increase', cat: 'Lighting' },
  0x5CCA: { label: 'RGB BRI-', name: 'RGB Brightness Decrease', cat: 'Lighting' }
};

function getKeyLabel(code) {
  if (KEYCODES[code]) return KEYCODES[code].label;
  if (code >= 0x5100 && code <= 0x510F) return `MO(${code & 0x0F})`;
  if (code >= 0x5010 && code <= 0x501F) return `TO(${code & 0x0F})`;
  return `0x${code.toString(16).toUpperCase()}`;
}

async function readKeymap() {
  const dev = getViaDevice();
  const totalBytes = LAYERS * ROWS * COLS * 2;
  const buffer = Buffer.alloc(totalBytes, 0);
  const chunkSize = 28;

  try {
    for (let offset = 0; offset < totalBytes; offset += chunkSize) {
      const size = Math.min(chunkSize, totalBytes - offset);
      const req = Buffer.alloc(33, 0);
      req[0] = 0x00;
      req[1] = 0x12; // CmdGetKeymapBuffer
      req[2] = (offset >> 8) & 0xff;
      req[3] = offset & 0xff;
      req[4] = size;

      dev.write([...req]);
      const resp = dev.readTimeout(1000);
      if (!resp || resp[0] !== 0x12) {
        throw new Error(`Failed to read keymap chunk at offset ${offset}`);
      }
      Buffer.from(resp).slice(4, 4 + size).copy(buffer, offset);
    }

    const keymap = [];
    for (let l = 0; l < LAYERS; l++) {
      const layer = [];
      for (let r = 0; r < ROWS; r++) {
        const row = [];
        for (let c = 0; c < COLS; c++) {
          const idx = (l * ROWS * COLS + r * COLS + c) * 2;
          const code = (buffer[idx] << 8) | buffer[idx + 1];
          row.push({
            code,
            hex: `0x${code.toString(16).padStart(4, '0')}`,
            label: getKeyLabel(code),
            name: KEYCODES[code] ? KEYCODES[code].name : 'Custom Keycode'
          });
        }
        layer.push(row);
      }
      keymap.push(layer);
    }

    return keymap;
  } finally {
    dev.close();
  }
}

async function setKeycode(layer, row, col, keycode) {
  const dev = getViaDevice();
  try {
    const req = Buffer.alloc(33, 0);
    req[0] = 0x00;
    req[1] = 0x05; // CmdSetKeycode
    req[2] = layer & 0xff;
    req[3] = row & 0xff;
    req[4] = col & 0xff;
    req[5] = (keycode >> 8) & 0xff;
    req[6] = keycode & 0xff;

    dev.write([...req]);
    const resp = dev.readTimeout(1000);
    if (!resp || resp[0] !== 0x05) {
      throw new Error(`Failed to set keycode at Layer ${layer}, Row ${row}, Col ${col}`);
    }

    return {
      success: true,
      layer,
      row,
      col,
      keycode,
      label: getKeyLabel(keycode)
    };
  } finally {
    dev.close();
  }
}

function getKeycodeCatalog() {
  const groups = {};
  for (const [code, info] of Object.entries(KEYCODES)) {
    const num = parseInt(code);
    const cat = info.cat || 'Other';
    if (!groups[cat]) groups[cat] = [];
    groups[cat].push({
      code: num,
      hex: `0x${num.toString(16).padStart(4, '0').toUpperCase()}`,
      label: info.label,
      name: info.name
    });
  }
  return groups;
}

module.exports = {
  readKeymap,
  setKeycode,
  getKeycodeCatalog,
  getKeyLabel,
  KEYCODES
};
