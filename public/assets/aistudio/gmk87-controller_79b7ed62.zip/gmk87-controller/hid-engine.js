const HID = require('node-hid');
const { Jimp } = require('jimp');

const VENDOR_ID = 0x320f;
const PRODUCT_ID = 0x5055;
const REPORT_ID = 0x04;
const DISPLAY_WIDTH = 240;
const DISPLAY_HEIGHT = 135;

let isDeviceLocked = false;
let cachedStatus = null;
let lastStatusReadTime = 0;
let cachedDevicePath = null;
let lastDeviceCloseTime = 0;

function lockDevice() {
  isDeviceLocked = true;
}

function unlockDevice() {
  isDeviceLocked = false;
}

function checksum(buf) {
  let sum = 0;
  for (let i = 3; i < 64; i++) {
    sum = (sum + (buf[i] & 0xff)) & 0xffff;
  }
  return sum;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function toRGB565(r, g, b) {
  const r5 = (r >> 3) & 0x1f;
  const g6 = (g >> 2) & 0x3f;
  const b5 = (b >> 3) & 0x1f;
  return (r5 << 11) | (g6 << 5) | b5;
}

function toHexNum(num) {
  if (num < 0 || num >= 100) return 0;
  const low = num % 10;
  const high = Math.floor(num / 10);
  return (high << 4) | low;
}

function fromBcd(val) {
  return ((val >> 4) * 10) + (val & 0x0f);
}

function getDevicePath() {
  if (cachedDevicePath) return cachedDevicePath;
  const devices = HID.devices();
  const d = devices.find(
    (x) => x.vendorId === VENDOR_ID && x.productId === PRODUCT_ID && x.interface === 3
  );
  if (d) cachedDevicePath = d.path;
  return d ? d.path : null;
}

async function openDevice() {
  const path = getDevicePath();
  if (!path) throw new Error('GMK87 not found in wired USB mode');

  const now = Date.now();
  if (now - lastDeviceCloseTime < 100) {
    await delay(100 - (now - lastDeviceCloseTime));
  }

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const dev = new HID.HID(path);
      return dev;
    } catch (e) {
      if (attempt < 2) {
        await delay(50);
      } else {
        throw e;
      }
    }
  }
}

function closeDevice(device) {
  if (device) {
    try {
      device.close();
    } catch (_) {}
    lastDeviceCloseTime = Date.now();
  }
}

async function safeWrite(device, buffer) {
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      device.write([...buffer]);
      return;
    } catch (err) {
      if (err.message && err.message.includes('0x000003E5') && attempt < 4) {
        await delay(40 * (attempt + 1));
      } else {
        throw err;
      }
    }
  }
}

async function readResponse(device, timeoutMs = 150) {
  try {
    const data = device.readTimeout(timeoutMs);
    if (!data || data.length === 0) return null;
    return Buffer.from(data);
  } catch (e) {
    return null;
  }
}

async function sendWithPosition(device, commandId, data = Buffer.alloc(0), pos = 0) {
  if (commandId === 2) {
    await delay(100);
  }

  const buffer = Buffer.alloc(64, 0x00);
  buffer[0] = REPORT_ID;
  buffer[3] = commandId;
  buffer[4] = data.length;
  buffer[5] = pos & 0xff;
  buffer[6] = (pos >> 8) & 0xff;
  buffer[7] = (pos >> 16) & 0xff;
  if (data.length > 0) {
    data.copy(buffer, 8);
  }

  const chk = checksum(buffer);
  buffer[1] = chk & 0xff;
  buffer[2] = (chk >> 8) & 0xff;

  await safeWrite(device, buffer);

  const start = Date.now();
  while (Date.now() - start < 800) {
    const resp = await readResponse(device, 100);
    if (!resp) {
      await delay(5);
      continue;
    }
    if (resp[3] === buffer[3]) {
      return resp.slice(4);
    }
  }
  return null;
}

async function readConfig(device) {
  await sendWithPosition(device, 0x01, Buffer.alloc(0), 0);
  for (let i = 0; i < 9; i++) {
    await sendWithPosition(device, 0x03, Buffer.alloc(4, 0x00), i * 4);
  }
  await sendWithPosition(device, 0x03, Buffer.alloc(1, 0x00), 36);
  await sendWithPosition(device, 0x02, Buffer.alloc(0), 0);

  const cfg = Buffer.alloc(48, 0x00);
  for (let i = 0; i < 12; i++) {
    const chunk = await sendWithPosition(device, 0x05, Buffer.alloc(4, 0x00), i * 4);
    if (chunk && chunk.length >= 4) {
      chunk.slice(0, 4).copy(cfg, i * 4);
    }
  }
  return cfg;
}

async function writeConfig(device, cfgBuffer) {
  await sendWithPosition(device, 0x01, Buffer.alloc(0), 0);
  await sendWithPosition(device, 0x06, cfgBuffer, 0);
  await sendWithPosition(device, 0x02, Buffer.alloc(0), 0);
  return true;
}

function drain(device) {
  for (let i = 0; i < 32; i++) {
    try {
      const r = device.readTimeout(20);
      if (!r || r.length === 0) break;
    } catch (_) {
      break;
    }
  }
}

// ----------------------------------------------------
// Public High-Level API (With Mutex Locking)
// ----------------------------------------------------

async function getStatus() {
  const now = Date.now();
  if (cachedStatus && (isDeviceLocked || (now - lastStatusReadTime < 30000))) {
    return cachedStatus;
  }
  if (isDeviceLocked) {
    return { connected: true, model: 'Zuoya GMK87' };
  }

  let device;
  try {
    device = await openDevice();
    const cfg = await readConfig(device);
    lastStatusReadTime = Date.now();

    const sec = fromBcd(cfg[35]);
    const min = fromBcd(cfg[36]);
    const hour = fromBcd(cfg[37]);
    const dayOfWeek = cfg[38];
    const date = fromBcd(cfg[39]);
    const month = fromBcd(cfg[40]);
    const year = 2000 + fromBcd(cfg[41]);

    const status = {
      connected: true,
      model: 'Zuoya GMK87',
      vendorId: '0x320F',
      productId: '0x5055',
      clock: {
        iso: `${year}-${String(month).padStart(2, '0')}-${String(date).padStart(2, '0')} ${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`,
        year, month, date, hour, min, sec, dayOfWeek
      },
      screen: {
        activeMode: cfg[33],
        slot0Frames: cfg[34],
        slot1Frames: cfg[46],
        frameDurationMs: cfg[43] | (cfg[44] << 8)
      },
      lighting: {
        effect: cfg[1],
        brightness: cfg[2],
        speed: cfg[3],
        hue: { r: cfg[6], g: cfg[7], b: cfg[8] },
        ledMode: cfg[28],
        ledColor: cfg[32]
      }
    };
    cachedStatus = status;
    return status;
  } catch (err) {
    cachedDevicePath = null;
    return { connected: false, error: err.message };
  } finally {
    closeDevice(device);
  }
}

async function syncTime() {
  while (isDeviceLocked) await delay(50);
  isDeviceLocked = true;

  let device;
  try {
    device = await openDevice();
    const cfg = await readConfig(device);

    const now = new Date();
    cfg[35] = toHexNum(now.getSeconds());
    cfg[36] = toHexNum(now.getMinutes());
    cfg[37] = toHexNum(now.getHours());
    cfg[38] = now.getDay() === 0 ? 7 : now.getDay();
    cfg[39] = toHexNum(now.getDate());
    cfg[40] = toHexNum(now.getMonth() + 1);
    cfg[41] = toHexNum(now.getFullYear() % 100);

    await writeConfig(device, cfg);
    return {
      success: true,
      syncedTo: now.toISOString(),
      displayTime: now.toLocaleTimeString()
    };
  } finally {
    closeDevice(device);
    isDeviceLocked = false;
  }
}

async function updateLighting({ brightness, speed, effect, hue }) {
  while (isDeviceLocked) await delay(50);
  isDeviceLocked = true;

  let device;
  try {
    device = await openDevice();
    const cfg = await readConfig(device);

    if (brightness !== undefined) cfg[2] = Math.max(0, Math.min(9, brightness));
    if (speed !== undefined) cfg[3] = Math.max(0, Math.min(4, speed));
    if (effect !== undefined) cfg[1] = Math.max(0, Math.min(20, effect));
    if (hue) {
      if (hue.r !== undefined) cfg[6] = hue.r & 0xff;
      if (hue.g !== undefined) cfg[7] = hue.g & 0xff;
      if (hue.b !== undefined) cfg[8] = hue.b & 0xff;
    }

    await writeConfig(device, cfg);
    return { success: true };
  } finally {
    closeDevice(device);
    isDeviceLocked = false;
  }
}

async function switchDisplaySlot(slot = 1) {
  while (isDeviceLocked) await delay(50);
  isDeviceLocked = true;

  let device;
  try {
    device = await openDevice();
    const cfg = await readConfig(device);
    cfg[33] = slot;
    await writeConfig(device, cfg);
    return { success: true, activeMode: slot };
  } finally {
    closeDevice(device);
    isDeviceLocked = false;
  }
}

function encodeRgb565Frame(pixelsRgba) {
  const frameSize = ((DISPLAY_WIDTH * DISPLAY_HEIGHT * 2) + 0x7fff) & ~0x7fff;
  const frameBuffer = Buffer.alloc(frameSize, 0x00);
  let idx = 0;
  for (let i = 0; i < DISPLAY_WIDTH * DISPLAY_HEIGHT; i++) {
    const pIdx = i * 4;
    const r = pixelsRgba[pIdx];
    const g = pixelsRgba[pIdx + 1];
    const b = pixelsRgba[pIdx + 2];
    const rgb565 = toRGB565(r, g, b);
    frameBuffer[idx++] = (rgb565 >> 8) & 0xff;
    frameBuffer[idx++] = rgb565 & 0xff;
  }
  return frameBuffer;
}

async function uploadRawFrames(framesBuffer, slot = 0, frameCount = 1, onProgress = () => {}) {
  // If caller already acquired lock via lockDevice(), avoid self-deadlock
  const wasLockedByCaller = isDeviceLocked;
  if (!wasLockedByCaller) {
    while (isDeviceLocked) await delay(50);
    isDeviceLocked = true;
  }

  let device;
  try {
    device = await openDevice();

    // 1. Read existing config
    const cfg = await readConfig(device);

    // 2. Update config for slot frame count & active display
    if (slot === 0) {
      cfg[34] = frameCount;
    } else {
      cfg[46] = frameCount;
    }
    cfg[33] = slot === 0 ? 1 : 2; // Auto-activate this slot!

    // Sync time along with it
    const now = new Date();
    cfg[35] = toHexNum(now.getSeconds());
    cfg[36] = toHexNum(now.getMinutes());
    cfg[37] = toHexNum(now.getHours());
    cfg[38] = now.getDay() === 0 ? 7 : now.getDay();
    cfg[39] = toHexNum(now.getDate());
    cfg[40] = toHexNum(now.getMonth() + 1);
    cfg[41] = toHexNum(now.getFullYear() % 100);

    // 3. Write configuration (sets frame count, active slot, time)
    await writeConfig(device, cfg);
    await delay(60);

    // 4. Start upload session: 0x23 (READY) - fast streaming write
    const buf23 = Buffer.alloc(64, 0x00);
    buf23[0] = REPORT_ID;
    buf23[3] = 0x23;
    const chk23 = checksum(buf23);
    buf23[1] = chk23 & 0xff;
    buf23[2] = (chk23 >> 8) & 0xff;
    await safeWrite(device, buf23);
    await delay(60);

    const totalBytes = framesBuffer.length;
    let pos = 0;
    let chunkCount = 0;
    while (pos < totalBytes) {
      const size = Math.min(56, totalBytes - pos);
      const chunk = framesBuffer.slice(pos, pos + size);

      const buffer = Buffer.alloc(64, 0x00);
      buffer[0] = REPORT_ID;
      buffer[3] = 0x21;
      buffer[4] = size;
      buffer[5] = pos & 0xff;
      buffer[6] = (pos >> 8) & 0xff;
      buffer[7] = (pos >> 16) & 0xff;
      chunk.copy(buffer, 8);
      const chk = checksum(buffer);
      buffer[1] = chk & 0xff;
      buffer[2] = (chk >> 8) & 0xff;

      await safeWrite(device, buffer);

      pos += size;
      chunkCount++;
      if (pos % 65536 === 0) {
        // Frame boundary: yield 25ms to let SPI flash complete sector write
        await delay(25);
      } else if (chunkCount % 16 === 0) {
        // Micro-yield to maintain USB bus timing
        await delay(1);
      }
      onProgress(Math.floor((pos / totalBytes) * 100));
    }

    // Final commit (0x02)
    await delay(100);
    const buf02 = Buffer.alloc(64, 0x00);
    buf02[0] = REPORT_ID;
    buf02[3] = 0x02;
    const chk02 = checksum(buf02);
    buf02[1] = chk02 & 0xff;
    buf02[2] = (chk02 >> 8) & 0xff;
    await safeWrite(device, buf02);
    await delay(100);

    return { success: true, uploadedBytes: totalBytes, frames: frameCount };
  } finally {
    closeDevice(device);
    if (!wasLockedByCaller) {
      isDeviceLocked = false;
    }
  }
}

module.exports = {
  getStatus,
  syncTime,
  updateLighting,
  switchDisplaySlot,
  encodeRgb565Frame,
  uploadRawFrames,
  lockDevice,
  unlockDevice,
  DISPLAY_WIDTH,
  DISPLAY_HEIGHT
};
