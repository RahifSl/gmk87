const { exec } = require('child_process');
const path = require('path');

let lastMedia = {
  status: 'Inactive',
  title: 'No Media Playing',
  artist: 'Spotify / Browser',
  album: ''
};

function pollMedia() {
  const scriptPath = path.join(__dirname, 'get_media.ps1');
  const cmd = `powershell -ExecutionPolicy Bypass -File "${scriptPath}"`;
  exec(cmd, { timeout: 3000 }, (err, stdout) => {
    if (!err && stdout) {
      try {
        const data = JSON.parse(stdout.trim());
        if (data && data.Status && data.Status !== 'Error') {
          lastMedia = {
            status: data.Status,
            title: data.Title || 'Ready',
            artist: data.Artist || 'Desktop Audio',
            album: data.Album || ''
          };
        }
      } catch (_) {}
    }
  });
}

// Poll media status every 4 seconds
setInterval(pollMedia, 4000);
pollMedia();

function getNowPlaying() {
  return lastMedia;
}

module.exports = { getNowPlaying };
