const { Jimp } = require('jimp');

const W = 240;
const H = 135;

function createBongoCatFrames() {
  const frames = [];
  const frameCount = 8;

  for (let f = 0; f < frameCount; f++) {
    const img = new Jimp({ width: W, height: H, color: 0x181e28ff });
    const pawState = f % 2; // 0 = left tap, 1 = right tap

    // Background gradient / desk
    for (let x = 0; x < W; x++) {
      for (let y = 90; y < H; y++) {
        img.setPixelColor(0x2a3242ff, x, y); // desk
      }
    }

    // Mini GMK87 keyboard on desk
    for (let x = 70; x < 170; x++) {
      for (let y = 98; y < 125; y++) {
        img.setPixelColor(0x384152ff, x, y);
      }
    }
    // Keycaps highlight
    for (let x = 75; x < 165; x += 10) {
      for (let y = 102; y < 120; y += 7) {
        for (let dx = 0; dx < 7; dx++) {
          for (let dy = 0; dy < 5; dy++) {
            img.setPixelColor(0x60a5faff, x + dx, y + dy);
          }
        }
      }
    }

    // Cat Body / Head (centered at 120, 60)
    for (let x = 85; x <= 155; x++) {
      for (let y = 30; y <= 90; y++) {
        const dx = (x - 120) / 32;
        const dy = (y - 62) / 28;
        if (dx * dx + dy * dy <= 1) {
          img.setPixelColor(0xffffffff, x, y);
        }
      }
    }

    // Cat Ears
    for (let y = 15; y <= 35; y++) {
      for (let x = 85 + (35 - y); x <= 105; x++) img.setPixelColor(0xffffffff, x, y);
      for (let x = 135; x <= 155 - (35 - y); x++) img.setPixelColor(0xffffffff, x, y);
    }
    // Pink inside ears
    for (let y = 22; y <= 32; y++) {
      for (let x = 93; x <= 98; x++) img.setPixelColor(0xf472b6ff, x, y);
      for (let x = 142; x <= 147; x++) img.setPixelColor(0xf472b6ff, x, y);
    }

    // Eyes
    for (let x = 104; x <= 108; x++) {
      for (let y = 56; y <= 62; y++) img.setPixelColor(0x0f172aff, x, y);
    }
    for (let x = 132; x <= 136; x++) {
      for (let y = 56; y <= 62; y++) img.setPixelColor(0x0f172aff, x, y);
    }
    // Blushing cheeks
    for (let x = 96; x <= 102; x++) img.setPixelColor(0xfb7185ff, x, 68);
    for (let x = 138; x <= 144; x++) img.setPixelColor(0xfb7185ff, x, 68);

    // Paws
    if (pawState === 0) {
      // Left paw down tapping keyboard, right paw up
      for (let x = 85; x <= 105; x++) for (let y = 92; y <= 105; y++) img.setPixelColor(0xffffffff, x, y);
      for (let x = 135; x <= 152; x++) for (let y = 78; y <= 90; y++) img.setPixelColor(0xffffffff, x, y);
    } else {
      // Right paw down tapping keyboard, left paw up
      for (let x = 88; x <= 105; x++) for (let y = 78; y <= 90; y++) img.setPixelColor(0xffffffff, x, y);
      for (let x = 135; x <= 155; x++) for (let y = 92; y <= 105; y++) img.setPixelColor(0xffffffff, x, y);
    }

    // Title Tag
    // We convert pixels
    const rgba = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const p = img.getPixelColor(x, y);
        rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
      }
    }
    frames.push(rgba);
  }
  return frames;
}

function createMatrixFrames() {
  const frames = [];
  const frameCount = 12;
  const colCount = 24;
  const colWidth = 10;
  const streamOffsets = Array.from({ length: colCount }, (_, i) => Math.floor(Math.sin(i * 1.5) * 8 + 10));

  for (let f = 0; f < frameCount; f++) {
    const img = new Jimp({ width: W, height: H, color: 0x050a06ff });

    for (let c = 0; c < colCount; c++) {
      const x = c * colWidth;
      const headY = ((f * 9 + streamOffsets[c] * 8) % (H + 40)) - 20;

      for (let i = 0; i < 14; i++) {
        const y = headY - i * 7;
        if (y >= 0 && y < H - 5) {
          const brightness = Math.max(0, 1 - (i / 14));
          const g = Math.floor(brightness * 255);
          const r = i === 0 ? 200 : Math.floor(g * 0.15);
          const b = i === 0 ? 220 : Math.floor(g * 0.15);
          const color = (r << 24) | (g << 16) | (b << 8) | 0xff;

          for (let dx = 2; dx < 6; dx++) {
            for (let dy = 0; dy < 4; dy++) {
              img.setPixelColor(color >>> 0, x + dx, y + dy);
            }
          }
        }
      }
    }

    const rgba = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const p = img.getPixelColor(x, y);
        rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
      }
    }
    frames.push(rgba);
  }
  return frames;
}

function createSynthwaveSunsetFrames() {
  const frames = [];
  const frameCount = 12;

  for (let f = 0; f < frameCount; f++) {
    const img = new Jimp({ width: W, height: H, color: 0x0d0417ff });

    // Sky gradient (deep purple to orange)
    for (let y = 0; y < 80; y++) {
      const factor = y / 80;
      const r = Math.floor(20 + factor * 210);
      const g = Math.floor(8 + factor * 70);
      const b = Math.floor(50 + (1 - factor) * 120);
      const skyCol = (r << 24) | (g << 16) | (b << 8) | 0xff;
      for (let x = 0; x < W; x++) img.setPixelColor(skyCol >>> 0, x, y);
    }

    // Neon Sun (radius 36, center 120, 68)
    for (let y = 25; y <= 75; y++) {
      // Horizontal sun cuts / blinds
      if ((y % 7) >= 5 && y >= 45) continue;
      for (let x = 75; x <= 165; x++) {
        const dx = (x - 120) / 36;
        const dy = (y - 68) / 36;
        if (dx * dx + dy * dy <= 1) {
          const sunColor = 0xffe600ff; // bright yellow
          img.setPixelColor(sunColor, x, y);
        }
      }
    }

    // 3D Grid Plane (y from 80 to 135)
    const offset = (f / frameCount) * 14;
    for (let y = 80; y < H; y++) {
      const depth = (y - 80) / 55;
      const gridGlow = Math.floor(depth * 255);
      const lineCol = (0xd9 << 24) | (0x46 << 16) | (gridGlow << 8) | 0xff;

      // Horizontal lines with perspective spacing
      const lineY = Math.floor(80 + Math.pow((y - 80) / 55, 1.8) * 55);
      if (Math.abs(y - lineY) < 1) {
        for (let x = 0; x < W; x++) img.setPixelColor(lineCol >>> 0, x, y);
      }
    }

    // Perspective lines
    for (let i = -7; i <= 7; i++) {
      const bottomX = 120 + i * 28 + (f % 2);
      for (let y = 80; y < H; y++) {
        const t = (y - 80) / 55;
        const x = Math.floor(120 + (bottomX - 120) * t);
        if (x >= 0 && x < W) {
          img.setPixelColor(0xec4899ff, x, y);
        }
      }
    }

    const rgba = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const p = img.getPixelColor(x, y);
        rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
      }
    }
    frames.push(rgba);
  }
  return frames;
}

function createCampfireFrames() {
  const frames = [];
  const frameCount = 8;

  for (let f = 0; f < frameCount; f++) {
    const img = new Jimp({ width: W, height: H, color: 0x090b10ff });

    // Distant dark trees silhouette
    for (let x = 0; x < W; x++) {
      const treeY = 85 + Math.sin(x / 12) * 6;
      for (let y = Math.floor(treeY); y < H; y++) {
        img.setPixelColor(0x131a24ff, x, y);
      }
    }

    // Campfire wood logs
    for (let i = 0; i < 20; i++) {
      img.setPixelColor(0x78350fff, 105 + i, 115 - Math.floor(i / 3));
      img.setPixelColor(0x78350fff, 135 - i, 115 - Math.floor(i / 3));
      img.setPixelColor(0x92400eff, 105 + i, 116 - Math.floor(i / 3));
    }

    // Fire flame particles
    const flameColors = [0xffedd5ff, 0xfde047ff, 0xf97316ff, 0xef4444ff];
    for (let i = 0; i < 50; i++) {
      const seed = (i * 37 + f * 17) % 100;
      const fx = 120 + Math.sin(seed + f) * (18 - (seed % 14));
      const fy = 112 - (seed % 42);
      const colIdx = Math.min(3, Math.floor((112 - fy) / 10));
      const col = flameColors[colIdx];

      for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          const px = Math.floor(fx + dx);
          const py = Math.floor(fy + dy);
          if (px >= 0 && px < W && py >= 0 && py < H) {
            img.setPixelColor(col, px, py);
          }
        }
      }
    }

    const rgba = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const p = img.getPixelColor(x, y);
        rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
      }
    }
    frames.push(rgba);
  }
  return frames;
}

// ----------------------------------------------------
// Pixel Art Font & HUD Rendering Engine
// ----------------------------------------------------

const FONT_4X6 = {
  '0': [0x6, 0x9, 0x9, 0x9, 0x9, 0x6],
  '1': [0x2, 0x6, 0x2, 0x2, 0x2, 0x7],
  '2': [0x6, 0x9, 0x1, 0x2, 0x4, 0xf],
  '3': [0xe, 0x1, 0x6, 0x1, 0x1, 0xe],
  '4': [0x9, 0x9, 0xf, 0x1, 0x1, 0x1],
  '5': [0xf, 0x8, 0xe, 0x1, 0x1, 0xe],
  '6': [0x6, 0x8, 0xe, 0x9, 0x9, 0x6],
  '7': [0xf, 0x1, 0x2, 0x4, 0x4, 0x4],
  '8': [0x6, 0x9, 0x6, 0x9, 0x9, 0x6],
  '9': [0x6, 0x9, 0x9, 0x7, 0x1, 0x6],
  ':': [0x0, 0x2, 0x0, 0x0, 0x2, 0x0],
  '%': [0x9, 0x2, 0x4, 0x2, 0x9, 0x0],
  'C': [0x7, 0x8, 0x8, 0x8, 0x8, 0x7],
  'P': [0xe, 0x9, 0xe, 0x8, 0x8, 0x8],
  'U': [0x9, 0x9, 0x9, 0x9, 0x9, 0x6],
  'R': [0xe, 0x9, 0xe, 0xa, 0x9, 0x9],
  'A': [0x6, 0x9, 0xf, 0x9, 0x9, 0x9],
  'M': [0x9, 0xf, 0x9, 0x9, 0x9, 0x9],
  'G': [0x7, 0x8, 0xb, 0x9, 0x9, 0x7],
  'B': [0xe, 0x9, 0xe, 0x9, 0x9, 0xe],
  'K': [0x9, 0xa, 0xc, 0xa, 0x9, 0x9],
  'N': [0x9, 0xd, 0xb, 0x9, 0x9, 0x9],
  'O': [0x6, 0x9, 0x9, 0x9, 0x9, 0x6],
  'V': [0x9, 0x9, 0x9, 0x9, 0x6, 0x2],
  'L': [0x8, 0x8, 0x8, 0x8, 0x8, 0xf],
  'S': [0x7, 0x8, 0x6, 0x1, 0x1, 0xe],
  'T': [0xf, 0x2, 0x2, 0x2, 0x2, 0x2],
  'E': [0xf, 0x8, 0xe, 0x8, 0x8, 0xf],
  'D': [0xe, 0x9, 0x9, 0x9, 0x9, 0xe],
  'I': [0x7, 0x2, 0x2, 0x2, 0x2, 0x7],
  'F': [0xf, 0x8, 0xe, 0x8, 0x8, 0x8],
  'H': [0x9, 0x9, 0xf, 0x9, 0x9, 0x9],
  'W': [0x9, 0x9, 0x9, 0x9, 0xf, 0x9],
  'Y': [0x9, 0x9, 0x6, 0x2, 0x2, 0x2],
  'Z': [0xf, 0x1, 0x2, 0x4, 0x8, 0xf],
  'X': [0x9, 0x9, 0x6, 0x6, 0x9, 0x9],
  'Q': [0x6, 0x9, 0x9, 0xb, 0xd, 0x7],
  'J': [0x1, 0x1, 0x1, 0x9, 0x9, 0x6],
  ' ': [0x0, 0x0, 0x0, 0x0, 0x0, 0x0],
  '-': [0x0, 0x0, 0xf, 0x0, 0x0, 0x0],
  '.': [0x0, 0x0, 0x0, 0x0, 0x2, 0x2],
  '/': [0x1, 0x2, 0x4, 0x4, 0x8, 0x8],
  '|': [0x2, 0x2, 0x2, 0x2, 0x2, 0x2],
  '>': [0x8, 0x4, 0x2, 0x4, 0x8, 0x0]
};

function drawText(img, text, startX, startY, color, scale = 1) {
  const str = String(text).toUpperCase();
  let curX = startX;
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    const glyph = FONT_4X6[ch] || FONT_4X6[' '];
    for (let row = 0; row < 6; row++) {
      const bits = glyph[row];
      for (let col = 0; col < 4; col++) {
        if ((bits >> (3 - col)) & 1) {
          for (let sx = 0; sx < scale; sx++) {
            for (let sy = 0; sy < scale; sy++) {
              const px = curX + col * scale + sx;
              const py = startY + row * scale + sy;
              if (px >= 0 && px < W && py >= 0 && py < H) {
                img.setPixelColor(color, px, py);
              }
            }
          }
        }
      }
    }
    curX += (4 + 1) * scale;
  }
}

function drawRect(img, x0, y0, w, h, color) {
  for (let x = x0; x < x0 + w; x++) {
    for (let y = y0; y < y0 + h; y++) {
      if (x >= 0 && x < W && y >= 0 && y < H) {
        img.setPixelColor(color, x, y);
      }
    }
  }
}

function drawHLine(img, x0, x1, y, color) {
  for (let x = x0; x <= x1; x++) {
    if (x >= 0 && x < W && y >= 0 && y < H) img.setPixelColor(color, x, y);
  }
}

// ----------------------------------------------------
// Feature 1: Dual-Layer Audio Visualizer Frames (24-Band Spectrum)
// ----------------------------------------------------

function createAudioVisualizerFrames(frameCount = 16) {
  const frames = [];
  const barCount = 22;
  const barWidth = 8;
  const barGap = 2;
  const startX = 12;
  const baseY = 115;
  const maxHeight = 85;

  for (let f = 0; f < frameCount; f++) {
    const img = new Jimp({ width: W, height: H, color: 0x060814ff });

    // Background Cyberpunk grid
    for (let y = 10; y < H; y += 15) drawHLine(img, 0, W - 1, y, 0x111628ff);

    // Header Title
    drawText(img, "GMK87 AUDIO SPECTRUM", 12, 8, 0x00f5ffff, 1);
    drawText(img, "LIVE FFT 32-BAND", 145, 8, 0xa855f7ff, 1);
    drawHLine(img, 10, W - 10, 18, 0x222a44ff);

    // Spectrum Bars
    for (let b = 0; b < barCount; b++) {
      const bx = startX + b * (barWidth + barGap);
      // Generate simulated frequency response with bass boost on left, mids, treble on right
      const freqFactor = Math.sin((b / barCount) * Math.PI) * 0.7 + 0.3;
      const wave = Math.sin(f * 0.45 + b * 0.55) * 0.35 + 0.65;
      const beat = (f % 4 === 0 && b < 6) ? 0.3 : 0.0;
      const height = Math.min(maxHeight, Math.floor((freqFactor * wave + beat) * maxHeight));

      for (let y = 0; y < height; y++) {
        const py = baseY - y;
        const progress = y / maxHeight;
        // Gradient: Cyan at bottom -> Purple in middle -> Amber/Red at peak
        let color = 0x06b6d4ff; // Cyan
        if (progress > 0.4) color = 0x8b5cf6ff; // Purple
        if (progress > 0.7) color = 0xec4899ff; // Pink
        if (progress > 0.88) color = 0xf59e0bff; // Amber/Gold
        drawRect(img, bx, py, barWidth, 1, color);
      }

      // Floating Peak Hold Dot
      const peakY = baseY - height - 3 - Math.floor(Math.sin(f * 0.3 + b) * 2);
      if (peakY >= 20) {
        drawRect(img, bx, peakY, barWidth, 2, 0xffffffff);
      }
    }

    // Oscilloscope Ribbon at bottom
    for (let x = 0; x < W; x++) {
      const waveY = Math.floor(125 + Math.sin(x * 0.08 + f * 0.4) * 5 * Math.cos(f * 0.2));
      if (waveY >= 0 && waveY < H) img.setPixelColor(0x38bdf8ff, x, waveY);
    }

    const rgba = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const p = img.getPixelColor(x, y);
        rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
      }
    }
    frames.push(rgba);
  }
  return frames;
}

// ----------------------------------------------------
// Feature 2: Contextual Rotary Knob OSD Frame
// ----------------------------------------------------

function createKnobOSDFrame(modeName = "SYSTEM VOLUME", icon = "VOL", valueText = "100%") {
  const img = new Jimp({ width: W, height: H, color: 0x090d16ff });

  // Border frame
  drawRect(img, 4, 4, W - 8, H - 8, 0x161e2eff);
  drawRect(img, 6, 6, W - 12, H - 12, 0x0c111cff);

  // Top header banner
  drawRect(img, 6, 6, W - 12, 22, 0x1e293bff);
  drawText(img, "ROTARY KNOB ACTIVE MODE", 18, 12, 0x38bdf8ff, 1);

  // Knob Icon Box
  drawRect(img, 20, 38, 48, 48, 0x1e293bff);
  drawRect(img, 22, 40, 44, 44, 0x0f172aff);
  drawText(img, icon, 26, 56, 0xf59e0bff, 2);

  // Mode Name Title
  drawText(img, modeName, 76, 42, 0xffffffff, 2);

  // Value / Description
  drawText(img, `VALUE: ${valueText}`, 76, 68, 0x10b981ff, 1);
  drawText(img, "TURN KNOB CW / CCW | CLICK TO CYCLE", 20, 102, 0x64748bff, 1);

  // Bottom glowing progress / dial bar
  drawRect(img, 20, 118, 200, 6, 0x334155ff);
  drawRect(img, 20, 118, 140, 6, 0x06b6d4ff);

  const rgba = [];
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const p = img.getPixelColor(x, y);
      rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
    }
  }
  return [rgba];
}

// ----------------------------------------------------
// Feature 3: Live Telemetry Dashboard HUD Frame
// ----------------------------------------------------

function createTelemetryHUDFrame(metrics = {}, media = {}) {
  const img = new Jimp({ width: W, height: H, color: 0x080c16ff });

  const cpu = metrics.cpuPercent !== undefined ? metrics.cpuPercent : 15;
  const usedMem = metrics.usedMemGb !== undefined ? metrics.usedMemGb : 12.4;
  const totalMem = metrics.totalMemGb !== undefined ? metrics.totalMemGb : 32.0;
  const memPct = metrics.memPercent !== undefined ? metrics.memPercent : 38;
  const uptime = metrics.uptimeHours !== undefined ? metrics.uptimeHours : 12.5;

  // Header Bar
  drawRect(img, 0, 0, W, 20, 0x111827ff);
  drawText(img, "GMK87 CYBER HUD", 10, 6, 0x00f5ffff, 1);
  const timeStr = new Date().toLocaleTimeString().toUpperCase();
  drawText(img, timeStr, 155, 6, 0x38bdf8ff, 1);
  drawHLine(img, 0, W - 1, 20, 0x1f2937ff);

  // CPU Box (Left)
  drawRect(img, 10, 26, 105, 42, 0x131d2eff);
  drawRect(img, 12, 28, 101, 38, 0x0a101dff);
  drawText(img, `CPU ${cpu}%`, 18, 33, 0x38bdf8ff, 2);
  // CPU Bar
  drawRect(img, 18, 52, 88, 7, 0x1e293bff);
  const cpuW = Math.max(2, Math.floor((cpu / 100) * 88));
  const cpuColor = cpu > 80 ? 0xef4444ff : (cpu > 50 ? 0xf59e0bff : 0x10b981ff);
  drawRect(img, 18, 52, cpuW, 7, cpuColor);

  // RAM Box (Right)
  drawRect(img, 125, 26, 105, 42, 0x131d2eff);
  drawRect(img, 127, 28, 101, 38, 0x0a101dff);
  drawText(img, `RAM ${memPct}%`, 133, 33, 0xa855f7ff, 2);
  // RAM Bar
  drawRect(img, 133, 52, 88, 7, 0x1e293bff);
  const ramW = Math.max(2, Math.floor((memPct / 100) * 88));
  drawRect(img, 133, 52, ramW, 7, 0x8b5cf6ff);

  // Media & Now Playing Area
  drawRect(img, 10, 74, 220, 36, 0x131d2eff);
  drawRect(img, 12, 76, 216, 32, 0x0a101dff);
  drawText(img, "NOW PLAYING", 18, 80, 0x64748bff, 1);
  const mediaTitle = (media.title && media.title !== 'Ready') ? media.title.slice(0, 22) : "DESKTOP AUDIO ACTIVE";
  drawText(img, mediaTitle, 18, 92, 0xfbbf24ff, 1);

  // Status Footer
  drawRect(img, 0, 116, W, 19, 0x0f172aff);
  drawText(img, `MEM: ${usedMem}G/${totalMem}G | UP: ${uptime}H`, 10, 122, 0x94a3b8ff, 1);

  const rgba = [];
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const p = img.getPixelColor(x, y);
      rgba.push((p >> 24) & 0xff, (p >> 16) & 0xff, (p >> 8) & 0xff, p & 0xff);
    }
  }
  return [rgba];
}

module.exports = {
  createBongoCatFrames,
  createMatrixFrames,
  createSynthwaveSunsetFrames,
  createCampfireFrames,
  createAudioVisualizerFrames,
  createKnobOSDFrame,
  createTelemetryHUDFrame
};
