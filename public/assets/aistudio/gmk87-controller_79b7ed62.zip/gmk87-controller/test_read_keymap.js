const HID = require('node-hid');

const VENDOR_ID = 0x320f;
const PRODUCT_ID = 0x5055;

function getViaDevice() {
  const d = HID.devices().find(x => x.vendorId === VENDOR_ID && x.productId === PRODUCT_ID && x.interface === 1);
  if (!d) throw new Error('GMK87 VIA interface not found');
  return new HID.HID(d.path);
}

async function readFullKeymap() {
  const dev = getViaDevice();
  const layers = 4;
  const rows = 8;
  const cols = 15;
  const totalBytes = layers * rows * cols * 2; // 960 bytes

  const buffer = Buffer.alloc(totalBytes, 0);
  const chunkSize = 28;

  try {
    for (let offset = 0; offset < totalBytes; offset += chunkSize) {
      const size = Math.min(chunkSize, totalBytes - offset);
      const req = Buffer.alloc(33, 0);
      req[0] = 0x00; // report id
      req[1] = 0x12; // CmdGetKeymapBuffer
      req[2] = (offset >> 8) & 0xff;
      req[3] = offset & 0xff;
      req[4] = size;

      dev.write([...req]);
      const resp = dev.readTimeout(1000);
      if (!resp || resp[0] !== 0x12) {
        throw new Error(`Failed to read keymap chunk at offset ${offset}`);
      }
      Buffer.from(resp).slice(4, 4 + size).copy(buffer, offset);
    }

    console.log(`Successfully read entire keymap: ${buffer.length} bytes!`);

    // Parse layer 0 keycodes
    const layer0 = [];
    for (let r = 0; r < rows; r++) {
      const rowKeys = [];
      for (let c = 0; c < cols; c++) {
        const idx = (0 * rows * cols + r * cols + c) * 2;
        const code = (buffer[idx] << 8) | buffer[idx + 1];
        rowKeys.push(`0x${code.toString(16).padStart(4, '0')}`);
      }
      layer0.push(rowKeys);
    }
    console.log('Layer 0 sample (Row 0, Esc & Function keys):', layer0[0]);
    return buffer;
  } finally {
    dev.close();
  }
}

readFullKeymap().catch(console.error);
