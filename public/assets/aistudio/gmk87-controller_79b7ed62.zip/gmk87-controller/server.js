const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const hid = require('./hid-engine');
const via = require('./via-engine');
const { Jimp } = require('jimp');
const { GifReader } = require('omggif');
const generators = require('./generators');
const media = require('./media-monitor');

const PORT = 3887;
const PUBLIC_DIR = path.join(__dirname, 'public');

let smartKnobEnabled = false;
let autoSyncInterval = null;
let activeKnobMode = 'volume';
let telemetryStreamTimer = null;
let isTelemetryStreaming = false;

// Auto-sync keyboard clock every 15 minutes to eliminate GMK87 drift
function startAutoSync() {
  if (autoSyncInterval) clearInterval(autoSyncInterval);
  autoSyncInterval = setInterval(async () => {
    try {
      await hid.syncTime();
      console.log(`[Auto-Sync] Clock updated at ${new Date().toLocaleTimeString()}`);
    } catch (_) {}
  }, 15 * 60 * 1000);
}
startAutoSync();

function sendJson(res, data, statusCode = 200) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(JSON.stringify(data));
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function getParsedLayout() {
  const raw = JSON.parse(fs.readFileSync(path.join(__dirname, 'gmk87-layout.json')));
  const kle = raw.layouts.keymap;
  const keys = [];
  let curY = 0;
  for (const r of kle) {
    let curX = 0, w = 1, h = 1;
    for (const it of r) {
      if (typeof it === 'object') {
        if (it.x) curX += it.x;
        if (it.y) curY += it.y;
        if (it.w) w = it.w;
        if (it.h) h = it.h;
        continue;
      }
      if (typeof it === 'string') {
        const p = it.split('\n')[0].split(',');
        if (p.length === 2) {
          keys.push({ row: +p[0], col: +p[1], x: curX, y: curY, w, h });
        }
        curX += w;
        w = 1;
        h = 1;
      }
    }
    curY += 1;
  }
  return keys;
}

function getSystemMetrics() {
  const cpus = os.cpus();
  let totalIdle = 0, totalTick = 0;
  cpus.forEach(cpu => {
    for (let type in cpu.times) {
      totalTick += cpu.times[type];
    }
    totalIdle += cpu.times.idle;
  });
  const cpuPercent = Math.round(100 - (100 * totalIdle / totalTick));
  const totalMem = Math.round(os.totalmem() / (1024 * 1024 * 1024) * 10) / 10;
  const freeMem = Math.round(os.freemem() / (1024 * 1024 * 1024) * 10) / 10;
  const usedMem = Math.round((totalMem - freeMem) * 10) / 10;
  const memPercent = Math.round((usedMem / totalMem) * 100);

  return {
    cpuPercent: Math.max(5, Math.min(99, cpuPercent)),
    totalMemGb: totalMem,
    usedMemGb: usedMem,
    memPercent,
    platform: os.platform(),
    uptimeHours: Math.round(os.uptime() / 3600 * 10) / 10
  };
}

async function searchWebGifs(query, page = 0) {
  try {
    const searchParam = encodeURIComponent(query + ' gif');
    const tokenRes = await fetch('https://duckduckgo.com/?q=' + searchParam);
    const html = await tokenRes.text();
    const match = html.match(/vqd=([\d-]+)/);
    if (!match) return [];
    const vqd = match[1];

    const apiUrl = `https://duckduckgo.com/i.js?q=${searchParam}&o=json&vqd=${vqd}&f=type:gif&s=${page * 30}`;
    const apiRes = await fetch(apiUrl);
    const data = await apiRes.json();
    const results = (data.results || []).filter(r => r.image && (r.image.includes('.gif') || r.thumbnail.includes('.gif') || r.source === 'Tenor' || r.source === 'Giphy' || r.source === 'DeviantArt' || r.source === 'Pixabay'));
    
    return results.slice(0, 30).map((r, i) => ({
      id: 'web_' + (page * 30 + i) + '_' + Math.random().toString(36).substring(7),
      title: r.title ? r.title.replace(/(&quot;|&#39;|&amp;|<[^>]+>)/g, '').substring(0, 45) : query + ' #' + (i + 1),
      url: r.image,
      preview: r.thumbnail || r.image,
      source: r.source || 'Web',
      width: r.width || 240,
      height: r.height || 135
    }));
  } catch (err) {
    console.error('Search error:', err);
    return [];
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host}`);

  // VIA Keymapping API Routes
  if (url.pathname === '/api/keymap' && req.method === 'GET') {
    try {
      const keymap = await via.readKeymap();
      return sendJson(res, keymap);
    } catch (err) {
      return sendJson(res, { error: err.message }, 500);
    }
  }

  if (url.pathname === '/api/layout' && req.method === 'GET') {
    try {
      const keys = getParsedLayout();
      return sendJson(res, { keys, rows: 8, cols: 15 });
    } catch (err) {
      return sendJson(res, { error: err.message }, 500);
    }
  }

  if (url.pathname === '/api/keycodes' && req.method === 'GET') {
    return sendJson(res, via.getKeycodeCatalog());
  }

  if (url.pathname === '/api/keymap/set' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const { layer, row, col, keycode } = body;
      const result = await via.setKeycode(layer, row, col, keycode);
      return sendJson(res, result);
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  // API Routes
  if (url.pathname === '/api/status' && req.method === 'GET') {
    const status = await hid.getStatus();
    status.pcTime = new Date().toLocaleTimeString();
    status.pcDate = new Date().toLocaleDateString();
    status.smartKnob = smartKnobEnabled;
    status.media = media.getNowPlaying();
    status.metrics = getSystemMetrics();
    return sendJson(res, status);
  }

  if (url.pathname === '/api/media' && req.method === 'GET') {
    return sendJson(res, media.getNowPlaying());
  }

  if (url.pathname === '/api/timesync' && req.method === 'POST') {
    try {
      const result = await hid.syncTime();
      return sendJson(res, result);
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  if (url.pathname === '/api/lighting' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const result = await hid.updateLighting(body);
      return sendJson(res, result);
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  async function applyKnobMode(mode) {
    activeKnobMode = mode;
    let ccwCode = 0x00aa; // VOL-
    let cwCode = 0x00a9;  // VOL+
    let muteCode = 0x00a8; // MUTE
    let icon = 'VOL';
    let title = 'SYSTEM VOLUME';
    let desc = 'AUDIO CONTROL';

    if (mode === 'media') {
      ccwCode = 0x00ac; // MPRV (Prev Track)
      cwCode = 0x00ab;  // MNXT (Next Track)
      muteCode = 0x00cd; // MPLY (Play/Pause)
      icon = 'MED';
      title = 'MEDIA PLAYER';
      desc = 'PREV / NEXT / PLAY';
    } else if (mode === 'scrub') {
      ccwCode = 0x0050; // Left Arrow
      cwCode = 0x004f;  // Right Arrow
      muteCode = 0x002c; // Spacebar
      icon = 'SCR';
      title = 'TIMELINE SCRUBBER';
      desc = 'SCRUB & PLAY/PAUSE';
    } else if (mode === 'zoom') {
      ccwCode = 0x004e; // Page Down
      cwCode = 0x004b;  // Page Up
      muteCode = 0x00b0; // Calculator
      icon = 'NAV';
      title = 'ZOOM & SCROLL';
      desc = 'PGUP / PGDN / CALC';
    }

    try {
      await via.setKeycode(0, 7, 0, ccwCode);
      await via.setKeycode(0, 7, 1, cwCode);
      await via.setKeycode(0, 0, 14, muteCode);
    } catch (e) {
      console.warn('[KnobMode] Could not write VIA keycode:', e.message);
    }

    try {
      const rawFrames = generators.createKnobOSDFrame(title, icon, desc);
      const encoded = rawFrames.map(f => hid.encodeRgb565Frame(f));
      await hid.uploadRawFrames(Buffer.concat(encoded), 0, 1, () => {});
    } catch (e) {
      console.warn('[KnobMode] Could not flash OSD frame:', e.message);
    }

    return { success: true, mode, title, icon, desc };
  }

  // Feature 2: Contextual Rotary Knob API
  if (url.pathname === '/api/knob-modes' && req.method === 'GET') {
    return sendJson(res, {
      activeMode: activeKnobMode,
      modes: [
        { id: 'volume', name: '🔊 System Volume', icon: 'VOL', desc: 'CCW: Vol- | CW: Vol+ | Click: Mute' },
        { id: 'media', name: '🎵 Media Player', icon: 'MED', desc: 'CCW: Prev Track | CW: Next Track | Click: Play/Pause' },
        { id: 'scrub', name: '⏩ Timeline Scrubber', icon: 'SCR', desc: 'CCW: Left Arrow | CW: Right Arrow | Click: Space' },
        { id: 'zoom', name: '🔍 Zoom & Scroll', icon: 'NAV', desc: 'CCW: Page Down | CW: Page Up | Click: Calculator' }
      ]
    });
  }

  if (url.pathname === '/api/knob-modes/select' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const resData = await applyKnobMode(body.mode || 'volume');
      return sendJson(res, resData);
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  // Feature 1: Dual-Layer Audio Visualizer API
  if (url.pathname === '/api/audio-visualizer/flash' && req.method === 'POST') {
    try {
      const rawFrames = generators.createAudioVisualizerFrames(16);
      const encoded = rawFrames.map(f => hid.encodeRgb565Frame(f));
      const totalBuffer = Buffer.concat(encoded);
      await hid.uploadRawFrames(totalBuffer, 0, 16, () => {});
      return sendJson(res, { success: true, frames: 16, slot: 0 });
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  // Feature 3: Live Telemetry Dashboard HUD API
  if (url.pathname === '/api/telemetry/flash' && req.method === 'POST') {
    try {
      const rawFrames = generators.createTelemetryHUDFrame(getSystemMetrics(), media.getNowPlaying());
      const encoded = rawFrames.map(f => hid.encodeRgb565Frame(f));
      const totalBuffer = Buffer.concat(encoded);
      await hid.uploadRawFrames(totalBuffer, 0, 1, () => {});
      return sendJson(res, { success: true, slot: 0, frames: 1 });
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  if (url.pathname === '/api/telemetry/stream' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const enable = !!body.enabled;
      if (enable && !isTelemetryStreaming) {
        isTelemetryStreaming = true;
        if (telemetryStreamTimer) clearInterval(telemetryStreamTimer);
        telemetryStreamTimer = setInterval(async () => {
          try {
            const rawFrames = generators.createTelemetryHUDFrame(getSystemMetrics(), media.getNowPlaying());
            const encoded = rawFrames.map(f => hid.encodeRgb565Frame(f));
            await hid.uploadRawFrames(Buffer.concat(encoded), 0, 1, () => {});
          } catch (_) {}
        }, 5000);
      } else if (!enable && isTelemetryStreaming) {
        isTelemetryStreaming = false;
        if (telemetryStreamTimer) {
          clearInterval(telemetryStreamTimer);
          telemetryStreamTimer = null;
        }
      }
      return sendJson(res, { success: true, streaming: isTelemetryStreaming });
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  if (url.pathname === '/api/switch-slot' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const result = await hid.switchDisplaySlot(body.slot || 1);
      return sendJson(res, result);
    } catch (err) {
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  if (url.pathname === '/api/smart-knob' && req.method === 'POST') {
    const body = await parseJsonBody(req);
    smartKnobEnabled = !!body.enabled;
    return sendJson(res, { success: true, enabled: smartKnobEnabled });
  }

  // Live Infinite Web GIF Search API (DuckDuckGo Image Engine)
  if (url.pathname === '/api/gifs/search' && req.method === 'GET') {
    const q = url.searchParams.get('q') || 'trending';
    const page = parseInt(url.searchParams.get('page') || '0', 10);
    const gifs = await searchWebGifs(q, page);
    return sendJson(res, { query: q, page, count: gifs.length, gifs });
  }

  // Curated GMK87 Library List (Offline & Online Web GIFs)
  if (url.pathname === '/api/library' && req.method === 'GET') {
    const libraryItems = [
      // Offline Built-in Generators
      {
        id: 'bongo_cat',
        title: '🐱 Bongo Cat Typing',
        category: 'Mascot & Gaming',
        description: 'The iconic mechanical keyboard mascot feverishly tapping keycaps on a mini GMK87!',
        frames: 8,
        tags: ['Cat', 'Pixel Art', 'Cute', 'Loop'],
        isBuiltin: true
      },
      {
        id: 'audio_spectrum',
        title: '🎵 24-Band Neon Audio Spectrum',
        category: 'Mascot & Gaming',
        description: 'Dynamic 24-band animated neon equalizer bars with floating peak hold dots & oscilloscope ribbon!',
        frames: 16,
        tags: ['Audio', 'Equalizer', 'Neon', 'Spectrum'],
        isBuiltin: true
      },
      {
        id: 'cyber_hud',
        title: '📊 Cyberpunk Telemetry HUD',
        category: 'Cyberpunk & Sci-Fi',
        description: 'Live real-time CPU & RAM gauges, active media title, and system uptime dashboard!',
        frames: 1,
        tags: ['HUD', 'Cyberpunk', 'Telemetry', 'Stats'],
        isBuiltin: true
      },
      {
        id: 'matrix_rain',
        title: '🌧️ Matrix Digital Rain',
        category: 'Cyberpunk & Sci-Fi',
        description: 'Futuristic falling binary streams and code cascades on pure black glass.',
        frames: 12,
        tags: ['Matrix', 'Cyberpunk', 'Green', 'Loop'],
        isBuiltin: true
      },
      {
        id: 'synthwave_sunset',
        title: '🌅 80s Synthwave Grid',
        category: 'Cozy & Aesthetic',
        description: 'Vibrant neon sun sinking over an endless perspective wireframe highway.',
        frames: 12,
        tags: ['Synthwave', 'Outrun', 'Neon', 'Loop'],
        isBuiltin: true
      },
      {
        id: 'campfire',
        title: '🔥 Cozy Pixel Campfire',
        category: 'Cozy & Aesthetic',
        description: 'Warm glowing fire with floating embers against dark mountain pines.',
        frames: 8,
        tags: ['Cozy', 'Fire', 'Atmospheric', 'Loop'],
        isBuiltin: true
      },

      // Pokemon Animated Battle Sprites (From Web CDN)
      {
        id: 'web_pikachu',
        title: '⚡ Pikachu Animated',
        category: 'Pokemon Animated',
        description: 'Classic electric mouse sparking with bouncing cheeks and lightning tail.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/25.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/25.gif',
        frames: 33,
        tags: ['Pokemon', 'Pikachu', 'Electric', 'Web']
      },
      {
        id: 'web_gengar',
        title: '👻 Gengar Mischief',
        category: 'Pokemon Animated',
        description: 'Shadow ghost pokemon laughing with glowing red eyes and purple flames.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/94.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/94.gif',
        frames: 38,
        tags: ['Pokemon', 'Gengar', 'Ghost', 'Purple']
      },
      {
        id: 'web_charizard',
        title: '🔥 Charizard Flying',
        category: 'Pokemon Animated',
        description: 'Flaming dragon hovering in air with flapping wings and burning tail.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/6.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/6.gif',
        frames: 42,
        tags: ['Pokemon', 'Charizard', 'Fire', 'Dragon']
      },
      {
        id: 'web_mewtwo',
        title: '🔮 Mewtwo Floating',
        category: 'Pokemon Animated',
        description: 'Legendary psychic creature hovering gracefully with aura pulses.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/150.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/150.gif',
        frames: 40,
        tags: ['Pokemon', 'Mewtwo', 'Psychic', 'Legendary']
      },
      {
        id: 'web_eevee',
        title: '🦊 Eevee Bouncing',
        category: 'Pokemon Animated',
        description: 'Cute fluffy normal-type fox jumping joyfully.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/133.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/133.gif',
        frames: 28,
        tags: ['Pokemon', 'Eevee', 'Cute']
      },
      {
        id: 'web_lucario',
        title: '🥋 Lucario Battle Stance',
        category: 'Pokemon Animated',
        description: 'Fighting/steel aura warrior ready to strike with martial focus.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/448.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/448.gif',
        frames: 35,
        tags: ['Pokemon', 'Lucario', 'Aura']
      },
      {
        id: 'web_snorlax',
        title: '💤 Snorlax Breathing',
        category: 'Pokemon Animated',
        description: 'Giant sleepy pokemon dozing peacefully on your keyboard display.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/143.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/143.gif',
        frames: 30,
        tags: ['Pokemon', 'Snorlax', 'Sleep', 'Chilled']
      },
      {
        id: 'web_rayquaza',
        title: '🐉 Rayquaza Ozone Serpent',
        category: 'Pokemon Animated',
        description: 'Legendary emerald sky serpent coiled with glowing yellow glyphs.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/384.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/384.gif',
        frames: 45,
        tags: ['Pokemon', 'Rayquaza', 'Legendary', 'Emerald']
      },
      {
        id: 'web_blastoise',
        title: '💧 Blastoise Hydro Cannons',
        category: 'Pokemon Animated',
        description: 'Mighty water tortoise with dual shell cannons ready for battle.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/9.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/9.gif',
        frames: 35,
        tags: ['Pokemon', 'Blastoise', 'Water', 'Kanto']
      },
      {
        id: 'web_umbreon',
        title: '🌙 Umbreon Moonlight Rings',
        category: 'Pokemon Animated',
        description: 'Dark-type Moonlight Pokemon with glowing gold rings and sleek stance.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/197.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/197.gif',
        frames: 32,
        tags: ['Pokemon', 'Umbreon', 'Dark', 'Eeveelution']
      },
      {
        id: 'web_mimikyu',
        title: '🎭 Mimikyu Disguise',
        category: 'Pokemon Animated',
        description: 'Spooky yet adorable fairy ghost hiding beneath a handmade cloth.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/778.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/778.gif',
        frames: 36,
        tags: ['Pokemon', 'Mimikyu', 'Ghost', 'Cute']
      },
      {
        id: 'web_shiny_gengar',
        title: '✨ Shiny White Gengar',
        category: 'Shiny Pokemon',
        description: 'Ultra-rare ghostly white shiny Gengar laughing into the void.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/94.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/94.gif',
        frames: 38,
        tags: ['Pokemon', 'Shiny', 'Gengar', 'Rare']
      },
      {
        id: 'web_shiny_charizard',
        title: '✨ Shiny Black Charizard',
        category: 'Shiny Pokemon',
        description: 'Menacing dark dragon with crimson wings and blue fire.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/6.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/6.gif',
        frames: 42,
        tags: ['Pokemon', 'Shiny', 'Charizard', 'Fire']
      },
      {
        id: 'web_shiny_rayquaza',
        title: '✨ Shiny Black Rayquaza',
        category: 'Shiny Pokemon',
        description: 'Legendary jet-black ozone serpent coiled in the sky.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/384.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/384.gif',
        frames: 45,
        tags: ['Pokemon', 'Shiny', 'Rayquaza', 'Legendary']
      },
      {
        id: 'web_shiny_umbreon',
        title: '✨ Shiny Blue-Ring Umbreon',
        category: 'Shiny Pokemon',
        description: 'Midnight dark fox with neon cyan glowing rings.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/197.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/197.gif',
        frames: 32,
        tags: ['Pokemon', 'Shiny', 'Umbreon', 'Dark']
      },
      {
        id: 'web_shiny_gyarados',
        title: '✨ Red Gyarados Lake of Rage',
        category: 'Shiny Pokemon',
        description: 'The infamous rampaging crimson sea serpent from Johto.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/130.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/shiny/130.gif',
        frames: 35,
        tags: ['Pokemon', 'Shiny', 'Gyarados', 'Red']
      },
      {
        id: 'web_haunter',
        title: '👻 Floating Haunter',
        category: 'Ghost & Psychic',
        description: 'Disembodied purple clawed shadow ghost hovering and licking.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/93.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/93.gif',
        frames: 34,
        tags: ['Pokemon', 'Ghost', 'Haunter']
      },
      {
        id: 'web_alakazam',
        title: '🥄 Alakazam Telekinesis',
        category: 'Ghost & Psychic',
        description: '5000 IQ psychic master floating dual spoons with glowing mind power.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/65.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/65.gif',
        frames: 30,
        tags: ['Pokemon', 'Psychic', 'Gen1']
      },
      {
        id: 'web_darkrai',
        title: '🌑 Darkrai Nightmare Pitch',
        category: 'Legendaries & Mythicals',
        description: 'Pitch-black shadow nightmare deity billowing in the night mist.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/491.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/491.gif',
        frames: 40,
        tags: ['Pokemon', 'Darkrai', 'Mythical', 'Dark']
      },
      {
        id: 'web_arceus',
        title: '✨ Arceus The Creator',
        category: 'Legendaries & Mythicals',
        description: 'The original Alpha Pokémon with divine wheel pulsing golden energy.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/493.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/493.gif',
        frames: 42,
        tags: ['Pokemon', 'Arceus', 'God', 'Legendary']
      },
      {
        id: 'web_lugia',
        title: '🌊 Lugia Diving Wing',
        category: 'Legendaries & Mythicals',
        description: 'Guardian of the seas flapping giant silver psychic wings.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/249.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/249.gif',
        frames: 38,
        tags: ['Pokemon', 'Lugia', 'Psychic', 'Flying']
      },
      {
        id: 'web_hooh',
        title: '🌈 Ho-Oh Rainbow Flight',
        category: 'Legendaries & Mythicals',
        description: 'Sacred rainbow phoenix radiating ancient Bell Tower flames.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/250.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/250.gif',
        frames: 38,
        tags: ['Pokemon', 'Ho-Oh', 'Fire', 'Flying']
      },
      {
        id: 'web_dragonite',
        title: '🧡 Dragonite Gentle Giant',
        category: 'Starters & Classics',
        description: 'Friendly orange dragon flapping tiny wings with cheerful spirit.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/149.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/149.gif',
        frames: 36,
        tags: ['Pokemon', 'Dragonite', 'Dragon', 'Cute']
      },
      {
        id: 'web_greninja',
        title: '🥷 Greninja Water Shuriken',
        category: 'Starters & Classics',
        description: 'Sleek ninja frog crouching with tongue scarf waving in the wind.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/658.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/658.gif',
        frames: 35,
        tags: ['Pokemon', 'Greninja', 'Ninja', 'Water']
      },
      {
        id: 'web_bulbasaur',
        title: '🌱 Bulbasaur Bouncing #001',
        category: 'Starters & Classics',
        description: 'Number 001 in the Pokédex hopping with fresh green bulb.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/1.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/1.gif',
        frames: 30,
        tags: ['Pokemon', 'Bulbasaur', 'Grass', 'Kanto']
      },
      {
        id: 'web_squirtle',
        title: '🐢 Squirtle Shell Bounce',
        category: 'Starters & Classics',
        description: 'Classic tiny turtle standing strong ready for water gun.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/7.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/7.gif',
        frames: 30,
        tags: ['Pokemon', 'Squirtle', 'Water', 'Kanto']
      },
      {
        id: 'web_charmander',
        title: '🦎 Charmander Tail Flame',
        category: 'Starters & Classics',
        description: 'Little fire lizard wagging its eternal flickering tail.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/4.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/4.gif',
        frames: 30,
        tags: ['Pokemon', 'Charmander', 'Fire', 'Kanto']
      },
      {
        id: 'web_mudkip',
        title: '🐟 Mudkip Fin Bounce',
        category: 'Starters & Classics',
        description: 'So I herd u liek Mudkips? The joyful blue Hoenn water starter!',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/258.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/258.gif',
        frames: 28,
        tags: ['Pokemon', 'Mudkip', 'Meme', 'Water']
      },
      {
        id: 'web_cyndaquil',
        title: '🔥 Cyndaquil Back Spikes',
        category: 'Starters & Classics',
        description: 'Timid Johto fire mouse bursting flames from its back.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/155.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/155.gif',
        frames: 32,
        tags: ['Pokemon', 'Cyndaquil', 'Fire', 'Johto']
      },
      {
        id: 'web_piplup',
        title: '🐧 Piplup Proud Stance',
        category: 'Starters & Classics',
        description: 'Proud little Sinnoh blue penguin puffing out its chest.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/393.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/393.gif',
        frames: 28,
        tags: ['Pokemon', 'Piplup', 'Water', 'Sinnoh']
      },
      {
        id: 'web_psyduck',
        title: '🦆 Psyduck Headache Confusion',
        category: 'Starters & Classics',
        description: 'Hilarious yellow duck holding its head while psychic power builds.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/54.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/54.gif',
        frames: 32,
        tags: ['Pokemon', 'Psyduck', 'Funny', 'Meme']
      },
      {
        id: 'web_sylveon',
        title: '🎀 Sylveon Fairy Ribbons',
        category: 'Starters & Classics',
        description: 'Pastel pink fairy Eeveelution waving soothing feelers.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/700.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/700.gif',
        frames: 34,
        tags: ['Pokemon', 'Sylveon', 'Fairy', 'Cute']
      },
      {
        id: 'web_jigglypuff',
        title: '🎤 Jigglypuff Singing Stance',
        category: 'Starters & Classics',
        description: 'Bouncy pink balloon preparing to sing you to sleep.',
        url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/39.gif',
        preview: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/39.gif',
        frames: 28,
        tags: ['Pokemon', 'Jigglypuff', 'Cute', 'Classic']
      }
    ];
    return sendJson(res, libraryItems);
  }

  // Flash GIF directly from any Web URL
  if (url.pathname === '/api/flash-url' && req.method === 'POST') {
    hid.lockDevice();
    try {
      const body = await parseJsonBody(req);
      const gifUrl = body.url;
      const slot = body.slot !== undefined ? body.slot : 0;
      if (!gifUrl) throw new Error('No URL provided');

      console.log(`Downloading online GIF from: ${gifUrl}`);
      let resp;
      try {
        resp = await fetch(gifUrl);
      } catch (_) {
        resp = await fetch(gifUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        });
      }
      if (!resp || !resp.ok) throw new Error(`HTTP ${resp ? resp.status : 'ERR'} - Could not download GIF from URL`);

      const arrayBuf = await resp.arrayBuffer();
      const inputBuffer = Buffer.from(arrayBuf);
      const isGif = inputBuffer[0] === 0x47 && inputBuffer[1] === 0x49 && inputBuffer[2] === 0x46;

      let framesBuffers = [];
      let frameCount = 1;

      if (isGif) {
        const reader = new GifReader(inputBuffer);
        const totalRaw = reader.numFrames();
        // Sample up to 16 frames evenly for high quality + 2-second lightning fast upload
        const maxFrames = 16;
        const frameIndices = [];
        if (totalRaw <= maxFrames) {
          for (let i = 0; i < totalRaw; i++) frameIndices.push(i);
        } else {
          for (let i = 0; i < maxFrames; i++) {
            frameIndices.push(Math.round(i * (totalRaw - 1) / (maxFrames - 1)));
          }
        }
        frameCount = frameIndices.length;
        const gWidth = reader.width;
        const gHeight = reader.height;

        const scale = Math.min(240 / gWidth, 135 / gHeight);
        const targetW = Math.max(1, Math.round(gWidth * scale));
        const targetH = Math.max(1, Math.round(gHeight * scale));
        const offsetX = Math.floor((240 - targetW) / 2);
        const offsetY = Math.floor((135 - targetH) / 2);

        const canvas = new Uint8Array(gWidth * gHeight * 4);
        for (let idx = 0; idx < frameIndices.length; idx++) {
          const f = frameIndices[idx];
          reader.decodeAndBlitFrameRGBA(f, canvas);
          const frameImg = new Jimp({ width: gWidth, height: gHeight, data: Buffer.from(canvas) });
          frameImg.resize({ w: targetW, h: targetH });

          const bgImg = new Jimp({ width: 240, height: 135, color: 0x000000ff });
          bgImg.composite(frameImg, offsetX, offsetY);
          framesBuffers.push(hid.encodeRgb565Frame(bgImg.bitmap.data));
        }
      } else {
        const jimg = await Jimp.read(inputBuffer);
        const gWidth = jimg.bitmap.width;
        const gHeight = jimg.bitmap.height;
        const scale = Math.min(240 / gWidth, 135 / gHeight);
        const targetW = Math.max(1, Math.round(gWidth * scale));
        const targetH = Math.max(1, Math.round(gHeight * scale));
        const offsetX = Math.floor((240 - targetW) / 2);
        const offsetY = Math.floor((135 - targetH) / 2);

        jimg.resize({ w: targetW, h: targetH });
        const bgImg = new Jimp({ width: 240, height: 135, color: 0x000000ff });
        bgImg.composite(jimg, offsetX, offsetY);
        framesBuffers.push(hid.encodeRgb565Frame(bgImg.bitmap.data));
      }

      const totalBuffer = Buffer.concat(framesBuffers);
      await hid.uploadRawFrames(totalBuffer, slot, frameCount, () => {});

      return sendJson(res, { success: true, slot, frames: frameCount });
    } catch (err) {
      console.error('Flash URL error:', err);
      return sendJson(res, { success: false, error: err.message }, 500);
    } finally {
      hid.unlockDevice();
    }
  }

  // Flash Curated Library Item directly to keyboard
  if (url.pathname === '/api/flash-library' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const itemId = body.id;
      const slot = body.slot !== undefined ? body.slot : 0;

      let rawFrames = [];
      let frameCount = 1;

      if (itemId === 'bongo_cat') {
        rawFrames = generators.createBongoCatFrames();
        frameCount = rawFrames.length;
      } else if (itemId === 'matrix_rain') {
        rawFrames = generators.createMatrixFrames();
        frameCount = rawFrames.length;
      } else if (itemId === 'synthwave_sunset') {
        rawFrames = generators.createSynthwaveSunsetFrames();
        frameCount = rawFrames.length;
      } else if (itemId === 'campfire') {
        rawFrames = generators.createCampfireFrames();
        frameCount = rawFrames.length;
      } else if (itemId === 'audio_spectrum') {
        rawFrames = generators.createAudioVisualizerFrames(16);
        frameCount = rawFrames.length;
      } else if (itemId === 'cyberpunk_hud' || itemId === 'cyber_hud') {
        rawFrames = generators.createTelemetryHUDFrame(getSystemMetrics(), media.getNowPlaying());
        frameCount = rawFrames.length;
      } else if (itemId === 'nyan_cat') {
        rawFrames = generators.createBongoCatFrames();
        frameCount = rawFrames.length;
      } else {
        throw new Error('Unknown library item ID: ' + itemId);
      }

      const encodedBuffers = rawFrames.map(f => hid.encodeRgb565Frame(f));
      const totalBuffer = Buffer.concat(encodedBuffers);

      await hid.uploadRawFrames(totalBuffer, slot, frameCount, () => {});

      return sendJson(res, { success: true, id: itemId, slot, frames: frameCount });
    } catch (err) {
      console.error('Flash library error:', err);
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  // Custom Image/GIF Upload
  if (url.pathname === '/api/upload-image' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const slot = body.slot !== undefined ? body.slot : 0;
      const dataUrl = body.image;
      if (!dataUrl) throw new Error('No image data provided');

      const base64Data = dataUrl.replace(/^data:image\/\w+;base64,/, '');
      const inputBuffer = Buffer.from(base64Data, 'base64');
      const isGif = dataUrl.startsWith('data:image/gif') || (inputBuffer[0] === 0x47 && inputBuffer[1] === 0x49 && inputBuffer[2] === 0x46);

      let framesBuffers = [];
      let frameCount = 1;

      if (isGif) {
        const reader = new GifReader(inputBuffer);
        frameCount = Math.min(reader.numFrames(), 64);
        const gWidth = reader.width;
        const gHeight = reader.height;

        const canvas = new Uint8Array(gWidth * gHeight * 4);
        for (let f = 0; f < frameCount; f++) {
          reader.decodeAndBlitFrameRGBA(f, canvas);
          const rawJimp = new Jimp({ width: gWidth, height: gHeight, data: Buffer.from(canvas) });
          rawJimp.resize({ w: 240, h: 135 });

          framesBuffers.push(hid.encodeRgb565Frame(rawJimp.bitmap.data));
        }
      } else {
        const jimg = await Jimp.read(inputBuffer);
        jimg.resize({ w: 240, h: 135 });
        framesBuffers.push(hid.encodeRgb565Frame(jimg.bitmap.data));
      }

      const totalBuffer = Buffer.concat(framesBuffers);
      await hid.uploadRawFrames(totalBuffer, slot, frameCount, () => {});

      return sendJson(res, { success: true, slot, frames: frameCount });
    } catch (err) {
      console.error('Upload custom image error:', err);
      return sendJson(res, { success: false, error: err.message }, 500);
    }
  }

  // Static files
  let filePath = path.join(PUBLIC_DIR, url.pathname === '/' ? 'index.html' : url.pathname);
  if (!fs.existsSync(filePath)) {
    filePath = path.join(PUBLIC_DIR, 'index.html');
  }

  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png'
  };

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
    } else {
      res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
      res.end(content);
    }
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`\n======================================================`);
  console.log(`🚀 GMK87 Ultimate Controller RUNNING at: http://localhost:${PORT}`);
  console.log(`======================================================\n`);
});
