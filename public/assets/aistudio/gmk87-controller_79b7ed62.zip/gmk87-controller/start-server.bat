@echo off
title Zuoya GMK87 Master Controller
cd /d "%~dp0"
echo Starting GMK87 Controller on http://localhost:3887 ...
node server.js
pause
